Special instructions
1.	Silk screen top and bottom white with supplied artwork.
2.	Copper external / internal 0.5 ounce.
3.	Hole sizes are finished size.  Tolerance is +-0.003".  Via tolerance is +0.003" � Via size.
4.	NA
5.	Material FR4, board thickness between 0.040" and 0.080".
6.	Minimum conductor width 0.003".
7.	Build / Manufacture to best commercial standards.



Enclosed files:
1)	Top.art		Top layer positive image artwork.
2)	L2 Layer 2 positive image artwork.
3)	L3 Layer 3 positive image artwork.
4)	L4 Layer 4 positive image artwork.
5)	L5 Layer 5 positive image artwork.
6)	Bottom.art	Bottom layer positive image artwork.
7)	Silk_T.art	Top layer silk screen.
8)	Silk_B.art	Bottom layer silk screen.
9)	sdr_msk_t.art Top layer Soldermask.
10)	sdr_msk_b.art Bottom layer Soldermask.
11)	NCDrill.art	Drill chart and board dimension.
12)	ncdrill1.tap	
13)	ncdrill.log
14) 	nc_param.txt