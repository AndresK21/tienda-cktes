Gerber Import Information
Units: Metric (mm)
Digit format: 4.3
Integer: 4
Decimal: 3
Mode: Absolute, Reference to relative origin
Zero suppression: Leading

Top Silk Screen:	DS28E17-EVKit-Rev1.GTO
Top Solder Mask:	DS28E17-EVKit-Rev1.GTS
Top Metal:		DS28E17-EVKit-Rev1.GTL
Top Paste Mask: 	DS28E17-EVKit-Rev1.GTP

Bottom Silk Screen:	DS28E17-EVKit-Rev1.GBO
Bottom Metal:		DS28E17-EVKit-Rev1.GBL
Bottom Solder Mask:	DS28E17-EVKit-Rev1.GBS

Board Outline:		DS28E17-EVKit-Rev1.GKO
Mechanical Info:	DS28E17-EVKit-Rev1.GM31

Drill Import Information
Units: Metric (mm)
Digit format: 4.3
Integer: 4
Decimal: 3
Mode: Absolute, Reference to relative origin
Zero suppression: None

ASCII drill file:	DS28E17-EVKit-Rev1.TXT

Drill Position file:	DS28E17-EVKit-Rev1.GG1
Drill Symbol file:	DS28E17-EVKit-Rev1.GD1

IPC-D-356 Netlist file:	DS28E17-EVKit-Rev1.net
